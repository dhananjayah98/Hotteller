package developers.bmsce.mank.com.foodorder.Model;

public class Result {

    public String message_id;
}
